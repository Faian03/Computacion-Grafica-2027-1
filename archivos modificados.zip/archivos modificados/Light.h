#pragma once

#include <glew.h>
#include <glm.hpp>

class Light
{
public:
	Light();
	Light(GLfloat red, GLfloat green, GLfloat blue, 
			GLfloat aIntensity, GLfloat dIntensity);

	void SetColor(const glm::vec3& nuevoColor) { color = nuevoColor; }
    // Estado en CPU: Shader excluye esta luz cuando esta apagada.
    void SetEncendida(bool valor) { encendida = valor; }
    bool EstaEncendida() const { return encendida; }
	~Light();

protected:
    bool encendida = true;
	glm::vec3 color;
	GLfloat ambientIntensity;
	GLfloat diffuseIntensity;
};

