#include "Cohete.h"
#include "Model.h"
#include "Material.h"
#include <cmath>
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>

namespace {
    Model cohete;
    float tiempoCohete = 0.0f;
}

void CargarCohete()
{
    cohete.LoadModel("Models/SaturnV/saturn_v.obj");
    tiempoCohete = 0.0f;
}

void ActualizarCohete(float segundos)
{
    tiempoCohete += segundos;
}

void DibujarCohete(GLuint uniformModel, GLuint uniformColor,
    GLuint uniformSpecularIntensity, GLuint uniformShininess)
{
    // Trayectoria: primero asciende y se va desviando hacia la derecha.
    float t = tiempoCohete;
    float x = -18.0f + 0.004f * t * t * t;
    float y = -2.0f + 0.2f * t * t;
    float z = 10.0f;

    // La inclinacion sigue la direccion de la trayectoria.
    // dx/dt = 0.012*t*t, dy/dt = 0.4*t; su cociente es 0.03*t.
    float inclinacion = -atan(0.03f * t); // atan devuelve radianes.
    glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(x, y, z));
    model = glm::rotate(model, inclinacion, glm::vec3(0.0f, 0.0f, 1.0f));
    glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
    glUniform3f(uniformColor, 1.0f, 1.0f, 1.0f);
    Material acabado(0.15f, 32.0f);
    acabado.UseMaterial(uniformSpecularIntensity, uniformShininess);
    cohete.RenderModel();
}
