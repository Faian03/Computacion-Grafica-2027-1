#pragma once
#include <glew.h>

void CargarCohete();
void ActualizarCohete(float segundos);
void DibujarCohete(GLuint uniformModel, GLuint uniformColor,
    GLuint uniformSpecularIntensity, GLuint uniformShininess);
