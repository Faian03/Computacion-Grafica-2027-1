#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>
#include <glm.hpp>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	GLfloat getmuevex() { return muevex; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
    int consumirVistaSolicitada() { int vista = vistaSolicitada; vistaSolicitada = 0; return vista; }
    glm::vec3 getColorFaroAvion() const;
    bool getLuzHolocronEncendida() const { return luzHolocronEncendida; }
    bool getLucesNave() const { return lucesNave; }
    bool getMotorNave(int i) const { return i >= 0 && i < 2 && motoresNave[i]; }
    bool getLuzPinzaEncendida() const { return luzPinzaEncendida; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	
	~Window();
private: 
	GLFWwindow *mainWindow = nullptr;
	GLint width, height;
	bool keys[1024];
    int vistaSolicitada = 0;
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX = 0.0f;
	GLfloat lastY = 0.0f;
	GLfloat xChange = 0.0f;
	GLfloat yChange = 0.0f;
	GLfloat muevex = 2.0f;
    int indiceColorFaroAvion = -1; // Blanco inicial; la primera pulsacion selecciona rojo.
    bool luzHolocronEncendida = true;
    bool luzPinzaEncendida = true;
    bool lucesNave = true;
    bool motoresNave[2] = { false, false };
	bool mouseFirstMoved = true;
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);

};

