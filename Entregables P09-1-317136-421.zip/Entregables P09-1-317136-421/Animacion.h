#pragma once
#include <glm.hpp>

// Variables de posicion y giro de los modelos.
enum EtapaVuelo { RECTA_IDA, VUELTA_FONDO, RECTA_REGRESO, VUELTA_FRENTE };
struct EstadoAnimacion {
    float x = 0.0f;
    bool avanza = true;
    float giroLlantas = 0.0f; // Giro de las llantas en grados.
    float zAvion = 14.0f;
    float giroAvion = 0.0f; // Giro del avion en la curva.
    EtapaVuelo etapa = RECTA_IDA;
    float xGhost = 0.0f;
    float zGhost = 15.0f;
    float yGhost = 0.0f;
    float inclinacionGhost = 0.0f;
    float giroGhost = 0.0f;
    int tramoGhost = 0;
    int pasoGhost = 0;
    float xSatelite = 0.0f;
    float ySatelite = 12.0f;
    int tramoSatelite = 0, pasoSatelite = 0;
    float giroComponentesSatelite[3] = { 0.0f, 0.0f, 0.0f };
    bool subenComponentesSatelite[3] = { true, false, true };
    double tiempoPendiente = 0.0;
};

extern EstadoAnimacion animacion;
extern const float mitadPiso, escalaRover, extremoIzquierdo, extremoDerecho, alturaCuerpo;
extern const glm::vec3 centroCuerpo;
extern const glm::vec3 pivotesRover[17];
extern const float escalaSatelite;
extern const glm::vec3 centroOrbitaSatelite;
extern const glm::vec3 pivotesSatelite[4];

void ActualizarAnimacion(EstadoAnimacion& estado, float segundos);
void ActualizarSatelite(EstadoAnimacion& estado);
glm::mat4 MatrizAvion(const EstadoAnimacion& estado);
glm::vec3 PosicionSatelite(const EstadoAnimacion& estado);
glm::mat4 BaseSatelite(const EstadoAnimacion& estado);
glm::mat4 MatrizPiezaSatelite(const EstadoAnimacion& estado, int pieza);

glm::vec3 PosicionGhost(const EstadoAnimacion& estado);
glm::mat4 MatrizGhost(const EstadoAnimacion& estado);
