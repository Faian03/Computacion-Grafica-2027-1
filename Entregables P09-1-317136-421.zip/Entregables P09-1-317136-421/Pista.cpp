#include "Pista.h"
#include <cmath>
#include "RecorridoGhost.h"

// Malla, textura y posicion de la pista.
MeshModel pistaCarreras;
Texture pistaTexture;
const glm::vec3 posicionPista(0.0f, 10.0f, 11.0f);

void GenerarGeometriaPista(std::vector<GLfloat>& vertices, std::vector<unsigned int>& indices)
{
    const int segmentos = 160;
    const float pi = 3.14159265f;
    for (int i = 0; i <= segmentos; ++i) {
        const float t = 2.0f * pi * i / segmentos;
        const float avanceTextura = i * 0.5f;
        const float altura = recorridoGhost[(40-i+segmentos)%segmentos].y;
        vertices.insert(vertices.end(), {
            28.0f * std::cos(t), altura, 13.0f * std::sin(t),
            0.0f, avanceTextura, 0.0f, 1.0f, 0.0f,
            // Centro del carril por donde pasa el Ghost.
            30.0f * std::cos(t), altura, 15.0f * std::sin(t),
            0.5f, avanceTextura, 0.0f, 1.0f, 0.0f,
            32.0f * std::cos(t), altura, 17.0f * std::sin(t),
            1.0f, avanceTextura, 0.0f, 1.0f, 0.0f
        });
    }
    for (int i = 0; i < segmentos; ++i) {
        const unsigned int a = 3 * i;
        // Une los puntos para formar los triangulos de la pista.
        indices.insert(indices.end(), { a, a+4, a+1, a+4, a, a+3, a+1, a+5, a+2, a+5, a+1, a+4 });
    }

    // Calcula las normales para iluminar las rampas.
    std::vector<glm::vec3> normales(vertices.size()/8,glm::vec3(0));
    const auto punto = [&vertices](unsigned int i) {
        return glm::vec3(vertices[i*8],vertices[i*8+1],vertices[i*8+2]);
    };
    for (size_t i=0;i<indices.size();i+=3) {
        const unsigned int a=indices[i],b=indices[i+1],c=indices[i+2];
        const glm::vec3 normal=glm::cross(punto(b)-punto(a),punto(c)-punto(a));
        normales[a]+=normal; normales[b]+=normal; normales[c]+=normal;
    }
    for(int borde=0;borde<3;++borde) {
        const glm::vec3 unionNormal=normales[borde]+normales[segmentos*3+borde];
        normales[borde]=unionNormal; normales[segmentos*3+borde]=unionNormal;
    }
    for(size_t i=0;i<normales.size();++i) {
        const glm::vec3 n=glm::normalize(normales[i]);
        vertices[i*8+5]=n.x; vertices[i*8+6]=n.y; vertices[i*8+7]=n.z;
    }
}

void CrearPistaCarreras()
{
    std::vector<GLfloat> vertices;
    std::vector<unsigned int> indices;
    GenerarGeometriaPista(vertices, indices);
    pistaCarreras.CreateMeshModel(vertices.data(), indices.data(),
        static_cast<unsigned int>(vertices.size()), static_cast<unsigned int>(indices.size()));
}
