#include "Animacion.h"
#include "RecorridoGhost.h"
#include <gtc/matrix_transform.hpp>
namespace { const float toRadians = 3.14159265f / 180.0f; }

// Posicion, tamano y puntos de giro del satelite.
const glm::vec3 centroOrbitaSatelite(0.0f, 16.0f, 11.0f);
const float escalaSatelite = 3.0f; // Tamano del satelite.
const glm::vec3 pivotesSatelite[] = {
    glm::vec3(0.0f), glm::vec3(0.0f, -0.213f, 0.15f),
    glm::vec3(0.0f, -0.213f, -0.15f), glm::vec3(-0.459f, -0.09f, 0.0f)
};

void OscilarComponente(float& angulo, bool& sube, float incremento, float limite)
{
    if (sube) {
        angulo += incremento;
        if (angulo >= limite) { angulo = limite; sube = false; }
    } else {
        angulo -= incremento;
        if (angulo <= -limite) { angulo = -limite; sube = true; }
    }
}

glm::vec3 PosicionSatelite(const EstadoAnimacion& estado)
{
    return centroOrbitaSatelite + glm::vec3(estado.xSatelite,estado.ySatelite,0.0f);
}

glm::mat4 BaseSatelite(const EstadoAnimacion& estado)
{
    glm::mat4 base = glm::translate(glm::mat4(1.0f),PosicionSatelite(estado));
    base = glm::rotate(base,65.0f*toRadians,glm::vec3(0,1,0));
    return glm::scale(base,glm::vec3(escalaSatelite));
}

glm::mat4 MatrizPiezaSatelite(const EstadoAnimacion& estado,int pieza)
{
    glm::mat4 model = glm::translate(BaseSatelite(estado),pivotesSatelite[pieza]);
    if (pieza > 0) {
        const glm::vec3 eje = pieza == 3 ? glm::vec3(0,0,1) : glm::vec3(1,0,0);
        model = glm::rotate(model,estado.giroComponentesSatelite[pieza-1]*toRadians,eje);
    }
    return model;
}

void ActualizarSatelite(EstadoAnimacion& estado)
{
        // Mueve el satelite por arriba y por debajo de la pista.
        const PasoGhost& pasoSat = recorridoGhost[estado.tramoSatelite];
        estado.xSatelite += pasoSat.dx * (56.0f/90.0f);
        estado.ySatelite += pasoSat.dz * (0.8f/3.0f);
        if (++estado.pasoSatelite >= 24) {
            estado.pasoSatelite = 0;
            if (++estado.tramoSatelite >= cantidadTramosGhost) estado.tramoSatelite = 0;
            const PasoGhost& siguiente = recorridoGhost[estado.tramoSatelite];
            estado.xSatelite = siguiente.x * (56.0f/30.0f);
            estado.ySatelite = siguiente.z * 0.8f;
        }
        OscilarComponente(estado.giroComponentesSatelite[0],estado.subenComponentesSatelite[0],0.30f,60.0f);
        OscilarComponente(estado.giroComponentesSatelite[1],estado.subenComponentesSatelite[1],0.27f,60.0f);
        OscilarComponente(estado.giroComponentesSatelite[2],estado.subenComponentesSatelite[2],0.20f,35.0f);

}
