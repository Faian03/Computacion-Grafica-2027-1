#pragma once
#include <vector>
#include "Mesh_tn.h"
#include "Texture.h"
#include <glm.hpp>
extern MeshModel pistaCarreras;
extern Texture pistaTexture;
extern const glm::vec3 posicionPista;
void GenerarGeometriaPista(std::vector<GLfloat>& vertices, std::vector<unsigned int>& indices);
void CrearPistaCarreras();
