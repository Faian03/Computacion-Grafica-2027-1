#include "Animacion.h"
#include "Pista.h"
#include "RecorridoGhost.h"
#include <gtc/matrix_transform.hpp>
namespace { const float toRadians = 3.14159265f / 180.0f; }

// Variables del Rover.
const float mitadPiso = 300.0f;
const float escalaRover = 0.3f;

const glm::vec3 centroCuerpo(-1.366451f, 3.685409f, 0.0f);
// Limites del Rover dentro del piso.
const float extremoIzquierdo = -mitadPiso + 5.023f * escalaRover;
const float extremoDerecho = mitadPiso - 8.320f * escalaRover;
const float alturaCuerpo = -2.0f + (3.685409f - 0.145f) * escalaRover;

const glm::vec3 pivotesRover[] = {
    centroCuerpo,
    {1.700f,5.180f,-1.100f}, {1.701f,5.982f,-1.100f},
    {4.236f,8.538f,-1.100f}, {1.588f,11.487f,-0.913f},
    {2.100f,4.208f,3.054f}, {2.100f,4.208f,-3.066f},
    {-3.040f,3.290f,3.000f}, {-3.040f,3.290f,-3.000f},
    {-3.040f,3.290f,3.000f}, {-3.040f,3.290f,-3.000f},
    {5.712f,1.705f,3.070f}, {5.710f,1.705f,-3.070f},
    {-0.945f,1.412f,4.159f}, {-0.947f,1.412f,-4.159f},
    {-5.131f,1.412f,4.159f}, {-5.113f,1.386f,-4.159f}
};

EstadoAnimacion animacion;

void ActualizarAnimacion(EstadoAnimacion& estado, float segundos)
{
    const double pasoTiempo = 1.0 / 60.0;
    estado.tiempoPendiente += segundos;
    while (estado.tiempoPendiente + 0.000001f >= pasoTiempo) {
        estado.tiempoPendiente -= pasoTiempo;
        // Actualiza la posicion y el giro del Ghost.
        const PasoGhost& paso = recorridoGhost[estado.tramoGhost];
        estado.xGhost += paso.dx;
        estado.zGhost += paso.dz;
        estado.giroGhost += paso.dgiro;
        estado.yGhost += paso.dy;
        estado.inclinacionGhost += paso.dinclinacion;
        if (++estado.pasoGhost >= pasosPorTramoGhost) {
            estado.pasoGhost = 0;
            if (++estado.tramoGhost >= cantidadTramosGhost) estado.tramoGhost = 0;
            const PasoGhost& siguiente = recorridoGhost[estado.tramoGhost];
            estado.xGhost = siguiente.x;
            estado.zGhost = siguiente.z;
            estado.giroGhost = siguiente.giro;
            estado.yGhost = siguiente.y;
            estado.inclinacionGhost = siguiente.inclinacion;
        }
        ActualizarSatelite(estado);
        // Mueve el Rover y gira las llantas.
        if (estado.avanza) {
            estado.x += 0.12f;
            estado.giroLlantas -= 11.0f;
            if (estado.x >= extremoDerecho) {
                estado.x = extremoDerecho;
                estado.avanza = false;
            }
        } else {
            estado.x -= 0.12f;
            estado.giroLlantas += 11.0f;
            if (estado.x <= extremoIzquierdo) {
                estado.x = extremoIzquierdo;
                estado.avanza = true;
            }
        }
        if (estado.giroLlantas >= 360.0f) estado.giroLlantas -= 360.0f;
        if (estado.giroLlantas <= -360.0f) estado.giroLlantas += 360.0f;

        // Mueve el avion por las rectas y las curvas.
        switch (estado.etapa) {
        case RECTA_IDA:
            estado.zAvion -= 0.12f;
            if (estado.zAvion <= -14.0f) {
                estado.zAvion = -14.0f;
                estado.giroAvion = 0.0f;
                estado.etapa = VUELTA_FONDO;
            }
            break;
        case VUELTA_FONDO:
            estado.giroAvion += 0.6f;
            if (estado.giroAvion >= 180.0f) {
                estado.giroAvion = 0.0f;
                estado.etapa = RECTA_REGRESO;
            }
            break;
        case RECTA_REGRESO:
            estado.zAvion += 0.12f;
            if (estado.zAvion >= 14.0f) {
                estado.zAvion = 14.0f;
                estado.giroAvion = 0.0f;
                estado.etapa = VUELTA_FRENTE;
            }
            break;
        case VUELTA_FRENTE:
            estado.giroAvion += 0.6f;
            if (estado.giroAvion >= 180.0f) {
                estado.giroAvion = 0.0f;
                estado.etapa = RECTA_IDA;
            }
            break;
        }
    }
}

glm::mat4 MatrizAvion(const EstadoAnimacion& estado)
{
    glm::mat4 matriz(1.0f);
    if (estado.etapa == RECTA_IDA) {
        matriz = glm::translate(matriz, glm::vec3(12.0f, 10.0f, estado.zAvion));
    } else if (estado.etapa == VUELTA_FONDO) {
        // Gira el avion alrededor del centro de la curva.
        matriz = glm::translate(matriz, glm::vec3(0.0f, 10.0f, -14.0f));
        matriz = glm::rotate(matriz, estado.giroAvion * toRadians, glm::vec3(0, 1, 0));
        matriz = glm::translate(matriz, glm::vec3(12.0f, 0.0f, 0.0f));
    } else if (estado.etapa == RECTA_REGRESO) {
        matriz = glm::translate(matriz, glm::vec3(-12.0f, 10.0f, estado.zAvion));
        matriz = glm::rotate(matriz, 180.0f * toRadians, glm::vec3(0, 1, 0));
    } else {
        matriz = glm::translate(matriz, glm::vec3(0.0f, 10.0f, 14.0f));
        matriz = glm::rotate(matriz, estado.giroAvion * toRadians, glm::vec3(0, 1, 0));
        matriz = glm::translate(matriz, glm::vec3(-12.0f, 0.0f, 0.0f));
        matriz = glm::rotate(matriz, 180.0f * toRadians, glm::vec3(0, 1, 0));
    }
    return glm::scale(matriz, glm::vec3(0.7f));
}

glm::vec3 PosicionGhost(const EstadoAnimacion& estado)
{
    return posicionPista+glm::vec3(estado.xGhost,estado.yGhost+0.25f,estado.zGhost);
}

glm::mat4 MatrizGhost(const EstadoAnimacion& estado)
{
    glm::mat4 model=glm::translate(glm::mat4(1.0f),PosicionGhost(estado));
    model=glm::rotate(model,estado.giroGhost*toRadians,glm::vec3(0,1,0));
    model=glm::rotate(model,estado.inclinacionGhost*toRadians,glm::vec3(0,0,1));
    return glm::scale(model,glm::vec3(0.62f));
}
