#include "Window.h"

Window::Window()
{
	width = 800;
	height = 600;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;
	muevex = 2.0f;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
int Window::Initialise()
{
	//Inicializaci�n de GLFW
	if (!glfwInit())
	{
		printf("Fall� inicializar GLFW");
		glfwTerminate();
		return 1;
	}
	//Asignando variables de GLFW y propiedades de ventana
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//para solo usar el core profile de OpenGL y no tener retrocompatibilidad
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	//CREAR VENTANA
	mainWindow = glfwCreateWindow(width, height, "E09-1-317136421 | Animacion basica", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo en crearse la ventana con GLFW");
		glfwTerminate();
		return 1;
	}
	//Obtener tama�o de Buffer
	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);

	//asignar el contexto
	glfwMakeContextCurrent(mainWindow);

	//MANEJAR TECLADO y MOUSE
	createCallbacks();


	//permitir nuevas extensiones
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("Fall� inicializaci�n de GLEW");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST); //HABILITAR BUFFER DE PROFUNDIDAD
							 // Asignar valores de la ventana y coordenadas
							 
							 //Asignar Viewport
	glViewport(0, 0, bufferWidth, bufferHeight);
	//Callback para detectar que se est� usando la ventana
	glfwSetWindowUserPointer(mainWindow, this);
	return 0;
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}
GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}




glm::vec3 Window::getColorFaroAvion() const
{
    // El ciclo de colores y las teclas se definen en Window.cpp.
    static const glm::vec3 colores[] = {
        glm::vec3(1.0f, 0.0f, 0.0f), // rojo
        glm::vec3(1.0f, 1.0f, 0.0f), // amarillo
        glm::vec3(0.0f, 1.0f, 0.0f), // verde
        glm::vec3(0.0f, 1.0f, 1.0f), // cian
        glm::vec3(0.0f, 0.0f, 1.0f), // azul
        glm::vec3(1.0f, 0.0f, 1.0f)  // magenta
    };
    return indiceColorFaroAvion < 0 ? glm::vec3(1.0f) : colores[indiceColorFaroAvion];
}

void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

    // Una accion por pulsacion: ignorar repeticion y una segunda PRESS sin soltar.
    if (key >= 0 && key < 1024 && action == GLFW_PRESS && !theWindow->keys[key])
    {
        switch (key)
        {
        case GLFW_KEY_F1:
            theWindow->vistaSolicitada = 1;
            break;
        case GLFW_KEY_F3:
            theWindow->vistaSolicitada = 3;
            break;
        case GLFW_KEY_F2:
            theWindow->vistaSolicitada = 2;
            break;
        case GLFW_KEY_1:
        {
            theWindow->indiceColorFaroAvion = (theWindow->indiceColorFaroAvion + 1) % 6;
            static const char* nombres[] = { "rojo", "amarillo", "verde", "cian", "azul", "magenta" };
            printf("Faro inferior del avion: %s\n", nombres[theWindow->indiceColorFaroAvion]);
            break;
        }
        case GLFW_KEY_2:
            theWindow->luzHolocronEncendida = !theWindow->luzHolocronEncendida;
            printf("Luz del holocron: %s\n", theWindow->luzHolocronEncendida ? "encendida" : "apagada");
            break;
        case GLFW_KEY_4:
            theWindow->lucesNave = !theWindow->lucesNave;
            printf("Luces de la nave: %s\n", theWindow->lucesNave ? "encendidas" : "apagadas");
            break;
        case GLFW_KEY_5:
        case GLFW_KEY_6:
        {
            int motor = key == GLFW_KEY_5 ? 0 : 1;
            theWindow->motoresNave[motor] = !theWindow->motoresNave[motor];
            printf("Motor %d (plasma y luz): %s\n", motor + 1, theWindow->motoresNave[motor] ? "encendido" : "apagado");
            break;
        }
        case GLFW_KEY_3:
            theWindow->luzPinzaEncendida = !theWindow->luzPinzaEncendida;
            printf("Luz de la pinza: %s\n", theWindow->luzPinzaEncendida ? "encendida" : "apagada");
            break;
        }
    }

    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}
	if (key == GLFW_KEY_Y)
	{
		theWindow-> muevex += 1.0;
	}
	if (key == GLFW_KEY_U)
	{
		theWindow-> muevex -= 1.0;
	}



	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
			//printf("se presiono la tecla %d'\n", key);
		}
		else if (action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
			//printf("se solto la tecla %d'\n", key);
		}
	}
}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;

	theWindow->lastX = xPos;
	theWindow->lastY = yPos;
}


Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();

}
